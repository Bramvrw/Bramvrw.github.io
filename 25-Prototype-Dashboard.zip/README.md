<h2>Dashboard prototype voor de NICE-registratie</h2>
Dit dashboard is een prototype waarin de informatie over de opnames op IC's in heel Nederland inzichtelijk wordt gemaakt. 
Deze informatie betreft het aantal IC opnames en verdere verdeling van deze opnames op opnametype en leeftijdscategorie. 
In het prototype wordt een maandoverzicht van mei 2023 en een jaaroverzicht van 2023 weergegeven met daarbij referentiewaarden van eerdere jaren. 
Dit prototype is gemaakt met echte data uit de Nice-registratie. 